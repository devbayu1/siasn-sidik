<?php $__env->startSection('title', 'Halaman Utama'); ?>
<?php $__env->startSection('content'); ?>

    <!-- Hero Section -->
    <section id="home" class="hero section">

        <div class="container" data-aos="fade-up" data-aos-delay="100">

            <div class="row align-items-center mb-5">
                <div class="col-lg-6 mb-4 mb-lg-0">

                    <h1 class="hero-title mb-4">Sistem Aplikasi Pengembangan Kompetensi (APKOM)</h1>

                    <p class="hero-description mb-4">Selamat datang di Website Sistem Aplikasi Pengembangan Kompetensi Badan Pendidikan dan Pelatihan Kabupaten Pacitan</p>

                    
                    <div class="cta-wrapper d-flex align-items-center">

                        
                        <img src="<?php echo e(asset('frontend/assets/img/logo_bm.png')); ?>" alt="Logo Bangga Melayani Bangsa"
                            style="height: 45px;" class="me-4">

                        
                        <img src="<?php echo e(asset('frontend/assets/img/logo_berakhlak.png')); ?>" alt="Logo BerAKHLAK"
                            style="height: 45px;">

                    </div>
                </div>

                <div class="col-lg-6">
                    <div class="hero-image">
                        <img src="frontend/assets/img/illustration/illustration-16.webp" alt="Business Growth"
                            class="img-fluid" loading="lazy">
                    </div>
                </div>
            </div>

        </div>

    </section><!-- /Hero Section -->

    <!-- Services Section -->
    <section id="about" class="services section">

        <!-- TENTANG APKOM -->
        <div class="container section-title" data-aos="fade-up">
            <h2>TENTANG APKOM</h2>
            <p><?php echo setting('tentang') ?? ''; ?></p>
        </div>
        <!-- End TENTANG APKOM -->

        <div class="container" data-aos="fade-up" data-aos-delay="100">

            <div class="row justify-content-center g-5">

                <?php if(count($abouts) > 0): ?>
                    <?php $__currentLoopData = $abouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6" data-aos="fade-right" data-aos-delay="100">
                            <div class="service-item">
                                <div class="service-icon">
                                    <i class="bi <?php echo e($item->icon); ?>"></i>
                                </div>
                                <div class="service-content">
                                    <h3><?php echo e($item->title); ?></h3>
                                    <p><?php echo e($item->description); ?></p>
                                </div>
                            </div>
                        </div><!-- End Service Item -->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php endif; ?>


            </div>

        </div>

    </section><!-- /Services Section -->


    <!-- Jalur Pendidikan -->
    <section id="jenis-pengembangan-kompetensi" class="about section light-background">
        <div class="container section-title" data-aos="fade-up">
            <h2>JENIS PENGEMBANGAN KOMPETENSI</h2>
        </div>
        <div class="container">

            <div class="row gy-4">

                <div class="col-lg-12 content" data-aos="fade-up" data-aos-delay="100">
                    <p>
                        <?php echo $pages->content; ?>

                    </p>
                </div>

            </div>

        </div>
    </section>
    <!-- /Jalur Pendidikan -->


    <!-- Tabel Konversi Section -->
    <section id="tabel-konversi" class="pricing section">

        <!-- Section Title -->
        <div class="container section-title" data-aos="fade-up">
            <h2>Tabel Konversi</h2>
            <p><?php echo setting('tabel-konversi') ?? ''; ?></p>
            <div class="text-center">
                Download <a href="<?php echo e(asset('storage/' . $tableConversion->file_path)); ?>" target="_blank">Disini</a>
            </div>
        </div><!-- End Section Title -->

    </section>
    <!-- /Tabel Konversi Section -->


    <!-- Faq PANDUAN -->
    <section id="faq" class="faq section  light-background">
        <!-- Section Title -->
        <div class="container section-title" data-aos="fade-up">
            <h2>PANDUAN</h2>
        </div><!-- End Section Title -->

        <div class="container" data-aos="fade-up" data-aos-delay="100">

            <div class="row gy-5">

                <div class="col-lg-12" data-aos="fade-up" data-aos-delay="300">
                    <div class="faq-accordion">
                        <?php if(count($faqs) > 0): ?>
                            <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="faq-item">
                                    <div class="faq-header">
                                        <h3><?php echo e($item->question); ?></h3>
                                        <i class="bi bi-chevron-down faq-toggle"></i>
                                    </div>
                                    <div class="faq-content">
                                        <p>
                                            <?php echo $item->answer; ?>

                                        </p>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <?php endif; ?>

                    </div>
                </div>
            </div>

        </div>

    </section>
    <!-- /Faq PANDUAN -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\sxampp\xampp82\htdocs\sidik\resources\views/frontend/home.blade.php ENDPATH**/ ?>