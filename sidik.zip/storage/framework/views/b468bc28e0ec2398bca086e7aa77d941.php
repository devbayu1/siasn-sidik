<?php if (isset($component)) { $__componentOriginalbe23554f7bded3778895289146189db7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbe23554f7bded3778895289146189db7 = $attributes; } ?>
<?php $component = Filament\View\LegacyComponents\Page::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::page'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Filament\View\LegacyComponents\Page::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="space-y-6">
        <?php if (isset($component)) { $__componentOriginalee08b1367eba38734199cf7829b1d1e9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalee08b1367eba38734199cf7829b1d1e9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.section.index','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
             <?php $__env->slot('title', null, []); ?> Pendaftaran Detail <?php $__env->endSlot(); ?>
             <?php $__env->slot('description', null, []); ?> Informasi lengkap mengenai pendaftaran <?php $__env->endSlot(); ?>

            <table
                class="w-full text-sm text-left text-gray-700 dark:text-white border border-gray-200 dark:border-gray-700">
                <tbody>
                    <tr>
                        <th class="p-2 font-medium w-1/3">Pegawai</th>
                        <td class="p-2"><?php echo e($record->employee->name); ?></td>
                    </tr>
                    <tr>
                        <th class="p-2 font-medium">Pelatihan Name</th>
                        <td class="p-2"><?php echo e($record->training_name); ?></td>
                    </tr>
                    <tr>
                        <th class="p-2 font-medium">Penyelenggara</th>
                        <td class="p-2"><?php echo e($record->organizer); ?></td>
                    </tr>
                    <tr>
                        <th class="p-2 font-medium">No. Sertifikat</th>
                        <td class="p-2"><?php echo e($record->certificate_number); ?></td>
                    </tr>
                    <tr>
                        <th class="p-2 font-medium">Mulai</th>
                        <td class="p-2"><?php echo e(\Carbon\Carbon::parse($record->start_date)->format('d M Y')); ?></td>
                    </tr>
                    <tr>
                        <th class="p-2 font-medium">Selesai</th>
                        <td class="p-2"><?php echo e(\Carbon\Carbon::parse($record->end_date)->format('d M Y')); ?></td>
                    </tr>
                    <tr>
                        <th class="p-2 font-medium">Tahun</th>
                        <td class="p-2"><?php echo e($record->year); ?></td>
                    </tr>
                    <tr>
                        <th class="p-2 font-medium">Durasi (jam)</th>
                        <td class="p-2"><?php echo e($record->duration_hours); ?></td>
                    </tr>
                    <tr>
                        <th class="p-2 font-medium">Diklat</th>
                        <td class="p-2"><?php echo e($record->diklat->name); ?></td>
                    </tr>
                    <tr>
                        <th class="p-2 font-medium">Sub Diklat</th>
                        <td class="p-2"><?php echo e($record->diklatSub?->name ?? '-'); ?></td>
                    </tr>
                    <tr>
                        <th class="p-2 font-medium">Status</th>
                        <td class="p-2"><?php echo e(ucfirst($record->status)); ?></td>
                    </tr>
                    <!--[if BLOCK]><![endif]--><?php if($record->status === 'rejected'): ?>
                        <tr>
                            <th class="p-2 font-medium text-red-600">Rejection Reason</th>
                            <td class="p-2 text-red-600"><?php echo e($record->rejection_reason); ?></td>
                        </tr>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </tbody>
            </table>

         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalee08b1367eba38734199cf7829b1d1e9)): ?>
<?php $attributes = $__attributesOriginalee08b1367eba38734199cf7829b1d1e9; ?>
<?php unset($__attributesOriginalee08b1367eba38734199cf7829b1d1e9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalee08b1367eba38734199cf7829b1d1e9)): ?>
<?php $component = $__componentOriginalee08b1367eba38734199cf7829b1d1e9; ?>
<?php unset($__componentOriginalee08b1367eba38734199cf7829b1d1e9); ?>
<?php endif; ?>

        <!--[if BLOCK]><![endif]--><?php if($record->certificate_file): ?>
            <?php if (isset($component)) { $__componentOriginalee08b1367eba38734199cf7829b1d1e9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalee08b1367eba38734199cf7829b1d1e9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.section.index','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                 <?php $__env->slot('title', null, []); ?> Certificate File <?php $__env->endSlot(); ?>

                <a href="<?php echo e(\Storage::url($record->certificate_file)); ?>" target="_blank"
                    class="text-blue-500 underline">
                    View Certificate
                </a>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalee08b1367eba38734199cf7829b1d1e9)): ?>
<?php $attributes = $__attributesOriginalee08b1367eba38734199cf7829b1d1e9; ?>
<?php unset($__attributesOriginalee08b1367eba38734199cf7829b1d1e9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalee08b1367eba38734199cf7829b1d1e9)): ?>
<?php $component = $__componentOriginalee08b1367eba38734199cf7829b1d1e9; ?>
<?php unset($__componentOriginalee08b1367eba38734199cf7829b1d1e9); ?>
<?php endif; ?>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbe23554f7bded3778895289146189db7)): ?>
<?php $attributes = $__attributesOriginalbe23554f7bded3778895289146189db7; ?>
<?php unset($__attributesOriginalbe23554f7bded3778895289146189db7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbe23554f7bded3778895289146189db7)): ?>
<?php $component = $__componentOriginalbe23554f7bded3778895289146189db7; ?>
<?php unset($__componentOriginalbe23554f7bded3778895289146189db7); ?>
<?php endif; ?>
<?php /**PATH G:\sxampp\xampp82\htdocs\sidik\resources\views/filament/resources/training-resource/pages/view-training.blade.php ENDPATH**/ ?>