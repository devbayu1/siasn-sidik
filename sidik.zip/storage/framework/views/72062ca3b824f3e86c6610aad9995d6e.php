<header id="header" class="header d-flex align-items-center fixed-top">
    <div class="container position-relative d-flex align-items-center justify-content-between">

        <a href="#" class="logo d-flex align-items-center me-auto me-xl-0">
            <!-- Uncomment the line below if you also wish to use an image logo -->
            
            <h1 class="sitename">APKOM</h1><span>.</span>
        </a>

        <nav id="navmenu" class="navmenu">
            <ul>
                <li><a href="<?php echo e(route('home')); ?>#home" class="active">Home</a></li>
                <li><a href="<?php echo e(route('home')); ?>#about">Tentang APKOM</a></li>
                <li><a href="<?php echo e(route('home')); ?>#jenis-pengembangan-kompetensi">Jenis Pengembangan Kompetensi</a></li>
                <li><a href="<?php echo e(route('home')); ?>#tabel-konversi">Tabel Konversi</a></li>
                <li><a href="<?php echo e(route('home')); ?>#faq">Panduan</a></li>
                <li><a href="<?php echo e(route('training')); ?>">
                        <button class="btn btn-primary">Form Diklat</button>
                    </a></li>
            </ul>
            <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
        </nav>

    </div>
</header>
<?php /**PATH G:\sxampp\xampp82\htdocs\sidik\resources\views/frontend/components/header.blade.php ENDPATH**/ ?>