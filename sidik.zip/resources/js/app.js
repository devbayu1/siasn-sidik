import './bootstrap';

// Import jQuery
import $ from 'jquery';
window.$ = window.jQuery = $;

// Import Select2 JS dan CSS
import 'select2';
import 'select2/dist/css/select2.min.css';
